package withPOs_noPageFactory;

import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ReceiptPage {
	WebDriver driver;
	By secondpage = By.tagName("H1");

	public ReceiptPage(WebDriver driver) {
		this.driver = driver;
	}

	public void set_secondpage() {
		Assertions.assertEquals("Thank you!", driver.findElement(secondpage).getText());
	}
}
