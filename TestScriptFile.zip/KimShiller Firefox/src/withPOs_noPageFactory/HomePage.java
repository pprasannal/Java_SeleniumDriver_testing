package withPOs_noPageFactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
	
	WebDriver driver;
	HomePage(WebDriver driver) {
		this.driver=driver;
	}
	By firstname =  By.id("firstname");
	By lastname =  By.id("lastname");
	By address =  By.id("address");
	By zipcode =  By.id("zipcode");
	By signup = By.id("signup");
	public void set_firstname(String text1) {
		driver.findElement(firstname).sendKeys(text1);
	}
	public void set_lastname(String text2) {
		driver.findElement(lastname).sendKeys(text2);
	}
	public void set_address(String text3) {
		driver.findElement(address).sendKeys(text3);
	}
	public void set_zipcode(String text4) {
		driver.findElement(zipcode).sendKeys(text4);
	}
	public void set_signup() {
		driver.findElement(signup).click();
	}
}
	
