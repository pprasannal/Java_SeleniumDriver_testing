package withPOs_noPageFactory;


import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import withPOs_noPageFactory.HomePage;
import withPOs_noPageFactory.ReceiptPage;

public class SimpleTestClass_withPageObjects {
	private static WebDriver driver;
	@BeforeEach
	public void startMethod() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\pl790\\Downloads\\chromedriver_win32 (8)\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	@Test
	public void testMethod() {
		driver.get("https://www.kimschiller.com/page-object-pattern-tutorial/");
		HomePage obj= new HomePage(driver);
		ReceiptPage obj1= new ReceiptPage(driver);
		obj.set_firstname("yandapalli");
		obj.set_lastname("poojitha");
		obj.set_address("tirupati 4-325");
		obj.set_zipcode("323728");
		obj.set_signup();
		obj1.set_secondpage();
	}
	@AfterAll
	public static void endOfTest() {
		driver.quit();
		System.out.println("Test completed");
	}
}