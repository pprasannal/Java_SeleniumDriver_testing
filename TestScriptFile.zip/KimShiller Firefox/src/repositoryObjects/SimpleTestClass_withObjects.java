package repositoryObjects;


import org.junit.jupiter.api.AfterAll;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import repositoryObjects.HomePage;
import repositoryObjects.ReceiptPage;

public class SimpleTestClass_withObjects {
	static WebDriver driver;
	@BeforeEach
	public void createAndStartService() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\pl790\\Downloads\\chromedriver_win32 (8)\\chromedriver.exe");/*selenium property , created path to the chromedriver*/
		driver = new ChromeDriver(); 
	}
	
	@Test
	void testMethod() {
		driver.get("https://www.kimschiller.com/page-object-pattern-tutorial/");
		HomePage.firstname(driver).sendKeys("yadapalli");
		HomePage.lastname(driver).sendKeys("poojitha");
		HomePage.address(driver).sendKeys("tirupathi, 4-232");
		HomePage.zipcode(driver).sendKeys("32736");
		System.out.println(HomePage.signup(driver).isDisplayed());
		System.out.println(HomePage.signup(driver).isEnabled());
		System.out.println(HomePage.signup(driver).isSelected());
		HomePage.signup(driver).click();
		Assertions.assertEquals("Thank you!",ReceiptPage.secondpage(driver).getText());
	}
	
	@AfterAll
	public static void endOfTest() {
		driver.quit();
		System.out.println("Test completed");
	}
}
