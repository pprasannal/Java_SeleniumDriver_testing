package repositoryObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ReceiptPage {
	static WebElement element;
	public static WebElement secondpage(WebDriver driver) {
		element = driver.findElement(By.tagName("H1"));
		return element;
	}
}
