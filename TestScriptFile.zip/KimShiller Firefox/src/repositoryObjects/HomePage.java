package repositoryObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {
	static WebElement element;
	public static WebElement firstname(WebDriver driver) {
		element = driver.findElement(By.id("firstname"));
		return element; 
	}
	public static WebElement lastname(WebDriver driver) {
		element = driver.findElement(By.id("lastname"));
		return element; 
	}
	public static WebElement address(WebDriver driver) {
		element = driver.findElement(By.id("address"));
		return element; 
	}
	public static WebElement zipcode(WebDriver driver) {
		element = driver.findElement(By.id("zipcode"));
		return element; 
	}
	public static WebElement signup(WebDriver driver) {
		element = driver.findElement(By.id("signup"));
		return element; 
	}
}
