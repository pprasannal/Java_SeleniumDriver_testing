package noPOM;

import org.junit.jupiter.api.AfterAll;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SimpleTestClass {

	static WebDriver driver;
	
	@BeforeEach
	public void createAndStartService() { 
		System.setProperty("webdriver.chrome.driver","C:\\Users\\pl790\\Downloads\\chromedriver_win32 (8)\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	@Test
	void testMethod() {
		driver.get("https://www.kimschiller.com/page-object-pattern-tutorial/");
		WebElement firstname= driver.findElement(By.id("firstname"));
		WebElement lastname= driver.findElement(By.id("lastname"));
		WebElement address= driver.findElement(By.id("address"));
		WebElement zipcode= driver.findElement(By.id("zipcode"));
		firstname.sendKeys("yadapalli");
		lastname.sendKeys("poojitha");
		address.sendKeys("tirupathi, 4-232");
		zipcode.sendKeys("32736");
		WebElement submitbutton = driver.findElement(By.id("signup"));
		System.out.println(submitbutton.isDisplayed());
		System.out.println(submitbutton.isEnabled());
		System.out.println(submitbutton.isSelected());
		submitbutton.click();
		Assertions.assertEquals("Thank you!",driver.findElement(By.tagName("H1")).getText());
	}
	@AfterAll
	public static void endOfTest() {
		driver.quit();
		System.out.println("Test completed");
	}
}
